import zlib
import time
import socket

class PacketHandler:
    def __init__(self):
        # Compression level: 1 (fastest) to 9 (maximum compression)
        self.compression_level = 6  # Default level

    def adjust_compression_level(self, connection_speed):
        """
        Adjusts compression level based on connection speed.
        :param connection_speed: Measured in Mbps (Megabits per second)
        """
        if connection_speed < 1:  # Slow connection
            self.compression_level = 9  # Max compression to reduce packet size
        elif connection_speed < 10:  # Medium speed
            self.compression_level = 6  # Balanced
        else:  # Fast connection
            self.compression_level = 1  # Faster compression for speed

    def compress_data(self, data):
        """
        Compresses outgoing data using zlib.
        :param data: Data to be compressed (bytes)
        :return: Compressed data (bytes)
        """
        try:
            compressed_data = zlib.compress(data, level=self.compression_level)
            return compressed_data
        except Exception as e:
            print(f"Error during compression: {e}")
            return None

    def inflate_data(self, compressed_data):
        """
        Decompresses incoming data using zlib.
        :param compressed_data: Compressed data to be inflated (bytes)
        :return: Decompressed data (bytes)
        """
        try:
            decompressed_data = zlib.decompress(compressed_data)
            return decompressed_data
        except Exception as e:
            print(f"Error during inflation: {e}")
            return None

    def measure_connection_speed(self, server_address, port=80):
        """
        Measures the connection speed to the given server.
        :param server_address: The address of the server to test against.
        :param port: The port to use for testing. Default is 80.
        :return: Connection speed in Mbps.
        """
        try:
            start_time = time.time()
            with socket.create_connection((server_address, port), timeout=5) as sock:
                sock.send(b"PING")
                sock.recv(4)
            end_time = time.time()
            elapsed_time = end_time - start_time
            connection_speed = 1 / elapsed_time * 8  # Arbitrary Mbps estimation
            return connection_speed
        except Exception as e:
            print(f"Error measuring connection speed: {e}")
            return 0  # Assume slow connection if speed cannot be measured

# Example usage
if __name__ == "__main__":
    handler = PacketHandler()
    
    # Example connection speed measurement
    server = "example.com"  # Replace with your server
    speed = handler.measure_connection_speed(server)
    print(f"Connection speed: {speed} Mbps")
    
    # Adjust compression level based on speed
    handler.adjust_compression_level(speed)
    print(f"Using compression level: {handler.compression_level}")

    # Example data
    data_to_send = b"This is a test packet for Jup1terdr0ps"
    print(f"Original data: {data_to_send}")

    # Compress data
    compressed = handler.compress_data(data_to_send)
    print(f"Compressed data: {compressed}")

    # Inflate data
    inflated = handler.inflate_data(compressed)
    print(f"Inflated data: {inflated}")
