# L1qu1d-Jup1ter
llama assisted sqlmap and xss with auto soft code script etc runner for linux like cortana but for pentester's an offline version of Ultron aka jup1ter
