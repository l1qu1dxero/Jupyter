import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
import subprocess
import os
import logging
from time import sleep
from ai_flow import AIFlow  # Ensure ai_flow.py is in the same directory
from tamper_and_fuzz import TamperAndFuzz  # Import engagement features

# Configure logging
logging.basicConfig(
    filename="pentest_tool.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


class PentestGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Pentesting GUI")
        self.ai_flow = AIFlow()  # Initialize AIFlow
        self.tamper_fuzz = None  # Initialize TamperAndFuzz later with target URL

        # Notebook for tabs
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(expand=1, fill="both")

        # Initialize tabs
        self.init_recon_tab()
        self.init_engage_tab()
        self.init_config_tab()

    def init_recon_tab(self):
        self.recon_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.recon_tab, text="Reconnaissance")

        # Recon Tab Elements
        tk.Label(self.recon_tab, text="Target URL:").grid(row=0, column=0, padx=5, pady=5)
        self.url_entry = tk.Entry(self.recon_tab, width=50)
        self.url_entry.grid(row=0, column=1, padx=5, pady=5)

        self.scan_button = tk.Button(self.recon_tab, text="Run Recon", command=self.run_recon)
        self.scan_button.grid(row=1, column=0, columnspan=2, pady=10)

        self.recon_output = scrolledtext.ScrolledText(self.recon_tab, width=80, height=20, state='disabled')
        self.recon_output.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

    def init_engage_tab(self):
        self.engage_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.engage_tab, text="Engagement")

        # Engagement Tab Elements
        tk.Label(self.engage_tab, text="Engagement Options").grid(row=0, column=0, padx=5, pady=5)
        tk.Button(self.engage_tab, text="Run Exploitation", command=self.run_exploitation).grid(row=1, column=0, pady=10)
        tk.Button(self.engage_tab, text="Upload Shell", command=self.upload_shell).grid(row=1, column=1, pady=10)
        tk.Button(self.engage_tab, text="Run Tamper & Fuzz", command=self.run_tamper_fuzz).grid(row=1, column=2, pady=10)

        self.engage_output = scrolledtext.ScrolledText(self.engage_tab, width=80, height=20, state='disabled')
        self.engage_output.grid(row=2, column=0, columnspan=3, padx=5, pady=5)

    def init_config_tab(self):
        self.config_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.config_tab, text="Configuration")

        # Configuration Tab Elements
        tk.Label(self.config_tab, text="SQLMap Parameters:").grid(row=0, column=0, padx=5, pady=5)
        self.sqlmap_params = tk.Entry(self.config_tab, width=50)
        self.sqlmap_params.grid(row=0, column=1, padx=5, pady=5)
        self.sqlmap_params.insert(0, "--batch --dump-all")

        tk.Label(self.config_tab, text="WAF Bypass:").grid(row=1, column=0, padx=5, pady=5)
        self.waf_bypass_var = tk.IntVar()
        tk.Checkbutton(self.config_tab, text="Enable WAF Bypass", variable=self.waf_bypass_var).grid(row=1, column=1, padx=5, pady=5)

    def run_recon(self):
        target_url = self.url_entry.get()
        if not target_url:
            messagebox.showerror("Error", "Please enter a valid target URL.")
            return
        self.log_to_output(self.recon_output, f"Running recon for {target_url}...")

        # Run LLaMA analysis
        try:
            strategy = self.ai_flow.analyze_target(target_url)
            self.log_to_output(self.recon_output, f"AI Strategy: {strategy}")
        except Exception as e:
            self.log_to_output(self.recon_output, f"Error during recon: {str(e)}", error=True)

    def run_exploitation(self):
        target_url = self.url_entry.get()
        if not target_url:
            messagebox.showerror("Error", "Please enter a valid target URL.")
            return
        self.log_to_output(self.engage_output, f"Running exploitation for {target_url}...")

        try:
            # Replace with real commands
            self.run_tool(["example_exploit_tool", "--target", target_url], "Exploitation", self.engage_output)
        except Exception as e:
            self.log_to_output(self.engage_output, f"Error during exploitation: {str(e)}", error=True)

    def upload_shell(self):
        target_url = self.url_entry.get()
        if not target_url:
            messagebox.showerror("Error", "Please enter a valid target URL.")
            return
        self.log_to_output(self.engage_output, f"Uploading shell to {target_url}...")

        try:
            # Replace with real commands
            self.run_tool(["example_shell_upload_tool", "--url", target_url, "--upload-shell"], "Shell Upload", self.engage_output)
        except Exception as e:
            self.log_to_output(self.engage_output, f"Error uploading shell: {str(e)}", error=True)

    def run_tamper_fuzz(self):
        target_url = self.url_entry.get()
        if not target_url:
            messagebox.showerror("Error", "Please enter a valid target URL.")
            return

        if not self.tamper_fuzz:
            self.tamper_fuzz = TamperAndFuzz(target_url)

        self.log_to_output(self.engage_output, "Running tamper and fuzzing operations...")
        try:
            self.tamper_fuzz.tamper_request()
            self.log_to_output(self.engage_output, "Tampering and fuzzing completed successfully.")
        except Exception as e:
            self.log_to_output(self.engage_output, f"Error during tamper and fuzzing: {str(e)}", error=True)

    def run_tool(self, command, tool_name, output_widget):
        try:
            process = subprocess.run(command, capture_output=True, text=True)
            self.log_to_output(output_widget, f"{tool_name} Output:\n{process.stdout}")
            if process.stderr:
                self.log_to_output(output_widget, f"{tool_name} Errors:\n{process.stderr}", error=True)
        except Exception as e:
            self.log_to_output(output_widget, f"Error running {tool_name}: {str(e)}", error=True)

    def log_to_output(self, widget, message, error=False):
        widget.config(state='normal')
        widget.insert(tk.END, f"{'[ERROR] ' if error else ''}{message}\n")
        widget.config(state='disabled')
        widget.see(tk.END)


# Main Execution
if __name__ == "__main__":
    root = tk.Tk()
    app = PentestGUI(root)
    root.mainloop()
