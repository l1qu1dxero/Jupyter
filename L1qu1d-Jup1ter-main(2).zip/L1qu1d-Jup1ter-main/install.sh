#!/bin/bash

# l1qu1d - Creator and Origin Contributor
# Disclaimer: No liability for damages or harm.
# Warning: Only use on permitted networks.

echo "======================================"
echo "l1qu1d - Creator and Origin Contributor"
echo "======================================"
echo "Disclaimer: No liability for damages or harm."
echo "Warning: Only use on permitted networks."
echo "Do you agree to these terms and conditions? (yes/no)"
read -r agree

if [ "$agree" != "yes" ]; then
    echo "You did not agree to the terms. Exiting script."
    exit 1
fi

echo "Starting installation of requirements..."

# Detect the OS and distribution
echo "Detecting operating system..."
os_name=$(grep '^ID=' /etc/os-release | cut -d'=' -f2 | tr -d '"')
os_version=$(grep '^VERSION_ID=' /etc/os-release | cut -d'=' -f2 | tr -d '"')

echo "Operating system detected: $os_name $os_version"

# Update package list
echo "Updating package list..."
sudo apt-get update -y

# Install common dependencies
echo "Installing common dependencies..."
sudo apt-get install -y python3 python3-pip git wget curl tar unzip

# Optional packages for network tools and scanning
echo "Installing optional tools (nmap, sqlmap, and hydra)..."
sudo apt-get install -y nmap sqlmap hydra

# Install pip requirements
if [ -f "requirements.txt" ]; then
    echo "Installing Python packages from requirements.txt..."
    pip3 install -r requirements.txt
else
    echo "requirements.txt not found. Skipping Python package installation."
fi

# Install Zaproxy (OWASP ZAP)
echo "Installing OWASP ZAP..."
sudo apt-get install -y zaproxy

# Install Burp Suite (Community Edition) if on Kali Linux
if [ "$os_name" == "kali" ]; then
    echo "Installing Burp Suite Community Edition (Kali Linux)..."
    sudo apt-get install -y burpsuite
else
    echo "Burp Suite Community Edition is not available on non-Kali systems. Skipping..."
fi

# Install Tor for anonymity
echo "Installing Tor for anonymity..."
sudo apt-get install -y tor

# Install LLaMA model dependencies and setup
echo "Setting up LLaMA model dependencies..."
LLAMA_DIR="./llama_model"
LLAMA_TAR="llama_model.tar.gz"
LLAMA_DOWNLOAD_URL="https://example.com/llama_model.tar.gz" # Replace with actual URL

mkdir -p "$LLAMA_DIR"
if [ ! -f "$LLAMA_DIR/$LLAMA_TAR" ]; then
    echo "Downloading LLaMA model..."
    wget -O "$LLAMA_DIR/$LLAMA_TAR" "$LLAMA_DOWNLOAD_URL"
    if [ $? -ne 0 ]; then
        echo "Error: Downloading the LLaMA model failed. Please check your internet connection or the URL."
        exit 1
    fi
    echo "Extracting LLaMA model..."
    tar -xzf "$LLAMA_DIR/$LLAMA_TAR" -C "$LLAMA_DIR"
    if [ $? -ne 0 ]; then
        echo "Error: Extracting the LLaMA model failed. Please check the tar file."
        exit 1
    fi
    echo "LLaMA model setup complete."
else
    echo "LLaMA model already exists. Skipping download."
fi

# Verify LLaMA model
if [ ! -d "$LLAMA_DIR" ]; then
    echo "Error: LLaMA model directory not found. Installation failed."
    exit 1
fi

echo "LLaMA model is ready for use."

# Ask user if they want to make the code globally accessible
echo "Do you want to make the code globally accessible? (yes/no)"
read -r make_global

if [ "$make_global" == "yes" ]; then
    # Create a symbolic link to the main script (assuming it is named main.py)
    if [ -f "main.py" ]; then
        sudo ln -sf "$(pwd)/main.py" /usr/local/bin/l1qu1d-jup1ter
        sudo chmod +x /usr/local/bin/l1qu1d-jup1ter
        echo "The code is now globally accessible as 'l1qu1d-jup1ter'."
    else
        echo "main.py not found. Cannot create global access. Please ensure the main script is named correctly."
    fi
else
    echo "The code will not be made globally accessible."
fi

echo "Installation complete. You can now run the code."
